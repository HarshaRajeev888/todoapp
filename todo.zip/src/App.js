import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import { Header } from './components/Header';

function App() {
  const [todos, setTodos] = useState([])
  const [todo, setTodo] = useState('')
  

  const deleteTask =(index)=>{
   var ask = window.confirm("do you want to delete the task?")
   if(ask){
     const test = [...todos]
     test.splice(index,1)
     setTodos(test)
   }else{
     console.log("dont delete");
   }
  }

  const restField = () =>{
    setTodo("")
  }
    const handleAdd = (e) =>{
    e.preventDefault();

    if(todo === ""){
      console.log("err");
      alert("filedis empty!")
      
    }else{
      restField()
    }
    }
 return (
    <div>
      <div>
        <Header />
        <form onSubmit={handleAdd}>
        <input value={todo} onChange={(e) => setTodo(e.target.value)} type="text" placeholder="Add item..." />
        <button onClick={() => setTodos([...todos, {  text: todo }])} >+</button>
        </form>
      </div>
      
     
{todos.map((obj,index) => {
return(
    <div>
      <p>{index+1}.{obj.text}    <button onClick={()=>deleteTask(index)}>del</button>
      </p>
   </div>
)
})}

</div>
  )}
   
export default App;
