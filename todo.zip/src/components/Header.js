import React from 'react'
import "../components/Header.css"

export const Header = () => {
    return (
        <div className="heading" >
            <h1>Todo App</h1>
            
        </div>
    )
}

{/* <div>
<Header />
<input value={todo} onChange={(e) => setTodo(e.target.value)} type="text" placeholder="Add item..." />
<button onClick={() => setTodos([...todos, { id: Date.now(), text: todo, status: false }])}>+</button>
</div> */}
